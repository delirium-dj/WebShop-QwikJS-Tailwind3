// src/routes/layout.tsx
// UPDATED VERSION with ToastProvider
import { component$, Slot } from '@builder.io/qwik';
import { CartProvider } from '~/contexts/cart';
import { ToastProvider } from '~/contexts/toast';

/**
 * Root Layout Component
 * Wraps app with both Cart and Toast providers
 */
export default component$(() => {
  return (
    <CartProvider>
      <ToastProvider>
        {/* Your existing header/layout */}
        <Slot />
        {/* Your existing footer */}
      </ToastProvider>
    </CartProvider>
  );
});
